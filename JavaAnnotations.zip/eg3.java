import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface ThinkingMachines
{
public int value() default 10; //here we have set the default value as 10 , so while using the Thinking machines annotation if any value is not passed then defaultly it will have 10
}
@ThinkingMachines //clearly nothing have passed here so, its default value i.e here 10 will be considered
class abcd
{

}
class psp
{
public static void main(String gg[])
{
Class a=abcd.class; //Class a=Class.forName("abcd");
Annotation aa=a.getAnnotation(ThinkingMachines.class);
if(aa!=null)
{
ThinkingMachines tm=(ThinkingMachines)aa;
System.out.println(tm.value());
}
}
}