import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface ThinkingMachines
{
public int value() default 10; //here we have set the default value as 10 , so while using the Thinking machines annotation if any value is not passed then defaultly it will have 10
public String city() default "Ujjain";
}
//clearly more than methods can have default values in annotation
@ThinkingMachines 
class abcd
{

}
class psp
{
public static void main(String gg[])
{
Class a=abcd.class; //Class a=Class.forName("abcd");
Annotation aa=a.getAnnotation(ThinkingMachines.class);
if(aa!=null)
{
ThinkingMachines tm=(ThinkingMachines)aa;
System.out.println(tm.value());
System.out.println(tm.city());
}
}
}