import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface ThinkingMachines
{
public int value() default 10; //here we have set the default value as 10 , so while using the Thinking machines annotation if any value is not passed then defaultly it will have 10
public String city() default "Ujjain";
}


//another annotation ->
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface Institute
{
}


@ThinkingMachines (value=20,city="Indore") 
@Institute
class abcd
{

}
class psp
{
public static void main(String gg[])
{
Class a=abcd.class; //Class a=Class.forName("abcd");
Annotation an[]=a.getAnnotations();
for(int e=0;e<an.length;e++)
{
System.out.println(an[e]);
if(an[e] instanceof Institute)
{
System.out.println("Institute annotation has been applied");
}
if(an[e] instanceof ThinkingMachines)
{
ThinkingMachines tm=(ThinkingMachines) an[e];
System.out.println("Thinking Machines annotation applied with value as : "+tm.value()+"and city as : "+tm.city());
}
}
}
}