import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface ThinkingMachines
{
public int value();
}
//since the method of name value is defined in annotation Thinking machines, so at the time of calling we have to pass the value of type int to it,since the return type of value is int
@ThinkingMachines(100)
class abcd
{

}
class psp
{
public static void main(String gg[])
{
Class a=abcd.class; //Class a=Class.forName("abcd");
Annotation aa=a.getAnnotation(ThinkingMachines.class);
if(aa!=null)
{
ThinkingMachines tm=(ThinkingMachines)aa;
System.out.println(tm.value());
}
}
}