import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) //this is for use annotation at runtime
@Target(ElementType.TYPE) 
@interface ThinkingMachines //creating annotation
{
}

@ThinkingMachines // by this applying annotation
class abcd
{

}

class pqrst
{

}

class psp
{
public static void main(String gg[])
{
Class a=abcd.class;
Class p=pqrst.class;
Annotation aa=a.getAnnotation(ThinkingMachines.class);
System.out.println(aa);
Annotation pp=p.getAnnotation(ThinkingMachines.class);
System.out.println(pp);
}
}